const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/authMiddleware');
const { updateProfile, getProfile } = require('../controllers/profileController');

// Оновити профіль
router.patch('/update-profile', authMiddleware, updateProfile);

// Отримати профіль
router.get('/my-profile', authMiddleware, getProfile);

module.exports = router;