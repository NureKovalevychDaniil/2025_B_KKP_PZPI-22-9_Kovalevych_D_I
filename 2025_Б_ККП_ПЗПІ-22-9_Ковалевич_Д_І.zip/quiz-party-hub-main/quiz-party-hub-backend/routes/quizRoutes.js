const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/authMiddleware');
const { generateQuiz } = require('../controllers/quizController');

// Генерація квізу
router.post('/generate-quiz', authMiddleware, generateQuiz);

module.exports = router;