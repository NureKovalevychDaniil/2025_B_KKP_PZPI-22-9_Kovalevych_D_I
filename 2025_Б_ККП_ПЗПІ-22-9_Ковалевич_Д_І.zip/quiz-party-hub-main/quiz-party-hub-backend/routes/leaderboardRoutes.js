const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/authMiddleware');
const { getLeaderboard } = require('../controllers/leaderboardController');

// Отримати лідерборд
router.get('/leaderboard', authMiddleware, getLeaderboard);

module.exports = router;