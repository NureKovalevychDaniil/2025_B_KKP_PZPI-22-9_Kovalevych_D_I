const express = require('express');
const router = express.Router();

// Тут поки нічого немає

module.exports = router;
