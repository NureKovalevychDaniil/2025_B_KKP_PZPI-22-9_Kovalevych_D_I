const express = require('express');
const router = express.Router();
const authMiddleware = require('../middlewares/authMiddleware');
const { updateScore } = require('../controllers/scoreController');

// Оновлення очок користувача
router.post('/update-score', authMiddleware, updateScore);

module.exports = router;