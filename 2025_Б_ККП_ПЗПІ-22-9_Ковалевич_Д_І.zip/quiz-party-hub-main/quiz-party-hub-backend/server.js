const express = require('express');
const cors = require('cors');
const dotenv = require('dotenv');

// Налаштування
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

// Підключення роутів
const quizRoutes = require('./routes/quizRoutes');
const userRoutes = require('./routes/userRoutes');
const leaderboardRoutes = require('./routes/leaderboardRoutes');
const scoreRoutes = require('./routes/scoreRoutes');
const profileRoutes = require('./routes/profileRoutes');

app.use('/api', quizRoutes);
app.use('/api', userRoutes);
app.use('/api', leaderboardRoutes);
app.use('/api', scoreRoutes);
app.use('/api', profileRoutes);

// Запуск сервера
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});