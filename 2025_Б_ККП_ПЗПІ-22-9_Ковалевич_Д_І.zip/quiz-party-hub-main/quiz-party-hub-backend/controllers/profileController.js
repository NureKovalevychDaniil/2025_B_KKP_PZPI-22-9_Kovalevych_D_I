const admin = require('firebase-admin');

// Оновити профіль користувача
const updateProfile = async (req, res) => {
  try {
    const userId = req.user.uid;
    const { displayName, avatarUrl } = req.body;

    const updates = {};
    if (displayName) updates.displayName = displayName;
    if (avatarUrl) updates.avatarUrl = avatarUrl;

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ message: 'Немає даних для оновлення.' });
    }

    const userRef = admin.firestore().collection('users').doc(userId);
    const userDoc = await userRef.get();

    // Якщо користувача немає — створити його
    if (!userDoc.exists) {
      await userRef.set({
        uid: userId,
        email: req.user.email || '',
        displayName: displayName || 'Без імені',
        avatarUrl: avatarUrl || '',
        score: 0,
        level: 'Новачок',
        createdAt: new Date().toISOString()
      });
    } else {
      // Якщо є — оновити
      await userRef.update(updates);
    }

    res.status(200).json({ message: 'Профіль оновлено успішно!' });
  } catch (error) {
    console.error('Error updating profile:', error);
    res.status(500).json({ message: 'Помилка при оновленні профілю.' });
  }
};

// Отримати профіль користувача
const getProfile = async (req, res) => {
  try {
    const userId = req.user.uid;
    const userRef = admin.firestore().collection('users').doc(userId);
    const userDoc = await userRef.get();

    if (!userDoc.exists) {
      // Автоматичне створення нового користувача
      const newUser = {
        uid: userId,
        email: req.user.email || '',
        displayName: req.user.name || 'Без імені',
        avatarUrl: '',
        score: 0,
        level: 'Новачок',
        createdAt: new Date().toISOString()
      };

      await userRef.set(newUser);
      return res.status(201).json(newUser);
    }

    const userData = userDoc.data();

    res.status(200).json({
      displayName: userData.displayName || 'Без імені',
      avatarUrl: userData.avatarUrl || '',
      score: userData.score || 0,
      level: userData.level || 'Новачок'
    });
  } catch (error) {
    console.error('Error fetching profile:', error);
    res.status(500).json({ message: 'Помилка при отриманні профілю.' });
  }
};

module.exports = { updateProfile, getProfile };