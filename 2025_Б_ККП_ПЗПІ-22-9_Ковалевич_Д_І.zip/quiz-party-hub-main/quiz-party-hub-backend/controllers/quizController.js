const { generatePrompt } = require('../utils/promptBuilder');
const { callGeminiAPI } = require('../services/geminiService');

const generateQuiz = async (req, res) => {
  try {
    const { topic, questionsCount = 10, mode = 'standard' } = req.body;

    if (!topic) {
      return res.status(400).json({ message: 'Тема обов\'язкова.' });
    }

    // Створюємо промт для Gemini
    const prompt = generatePrompt(topic, questionsCount);

    // Викликаємо Gemini API
    const questions = await callGeminiAPI(prompt);

    // Повертаємо також режим
    res.status(200).json({ questions, mode });
  } catch (error) {
    console.error('Error generating quiz:', error);
    res.status(500).json({ message: 'Помилка при генерації квізу' });
  }
};

module.exports = { generateQuiz };