const admin = require('firebase-admin');

const updateScore = async (req, res) => {
  try {
    let { score, duration, mode = 'standard' } = req.body;
    const userId = req.user.uid;

    const validModes = ['standard', 'sudden-death', 'timed'];
    if (!validModes.includes(mode)) {
      return res.status(400).json({ message: 'Невідомий режим гри.' });
    }

    if (typeof score !== 'number' || score <= 0) {
      return res.status(400).json({ message: 'Некоректне значення очок.' });
    }

    // Бонус за швидкість у режимі "timed"
    let bonus = 0;
    if (mode === 'timed' && typeof duration === 'number' && duration < 60) {
      bonus = 20;
      score += bonus;
    }

    const userRef = admin.firestore().collection('users').doc(userId);
    const userDoc = await userRef.get();

    if (!userDoc.exists) {
      await userRef.set({
        uid: userId,
        email: req.user.email,
        displayName: req.user.name || "Без імені",
        avatarUrl: "",
        score: score,
        level: "Новачок",
        lastMode: mode,
        lastDuration: duration || null
      });
    } else {
      const previousScore = userDoc.data().score || 0;
      const newScore = previousScore + score;

      await userRef.update({
        score: newScore,
        lastMode: mode,
        lastDuration: duration || null
      });
    }

    res.status(200).json({ message: 'Очки оновлено успішно!', bonus });
  } catch (error) {
    console.error('Error updating score:', error);
    res.status(500).json({ message: 'Помилка при оновленні очок.' });
  }
};

module.exports = { updateScore };