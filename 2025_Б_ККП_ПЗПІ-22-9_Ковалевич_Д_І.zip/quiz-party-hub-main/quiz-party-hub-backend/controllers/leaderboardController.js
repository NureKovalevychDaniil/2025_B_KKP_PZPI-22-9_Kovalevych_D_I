const admin = require('firebase-admin');

// Отримати топ-10 гравців за кількістю очок
const getLeaderboard = async (req, res) => {
  try {
    const usersSnapshot = await admin.firestore()
      .collection('users')
      .orderBy('score', 'desc')
      .limit(10)
      .get();

    const leaderboard = usersSnapshot.docs.map(doc => {
      const data = doc.data();
      return {
        displayName: data.displayName || 'Без імені',
        avatarUrl: data.avatarUrl || '',
        score: data.score || 0,
        level: data.level || 'Новачок',
      };
    });

    res.status(200).json({ leaderboard });
  } catch (error) {
    console.error('Error fetching leaderboard:', error);
    res.status(500).json({ message: 'Помилка при отриманні лідерборду.' });
  }
};

module.exports = { getLeaderboard };