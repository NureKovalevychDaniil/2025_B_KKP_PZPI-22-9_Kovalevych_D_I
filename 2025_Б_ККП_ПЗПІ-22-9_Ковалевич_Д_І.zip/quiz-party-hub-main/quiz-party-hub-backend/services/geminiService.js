const axios = require('axios');

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

// Виклик Gemini API
const callGeminiAPI = async (prompt) => {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

  const body = {
    contents: [
      {
        parts: [
          {
            text: prompt,
          },
        ],
      },
    ],
  };

  try {
    const response = await axios.post(url, body, {
      headers: {
        'Content-Type': 'application/json',
      },
    });

    let text = response.data.candidates[0]?.content?.parts[0]?.text;

    if (!text) {
    throw new Error('Gemini не повернув текст.');
    }

    // Очистити зайві трійні лапки ```json та ```
    text = text.replace(/^```json\s*/i, '').replace(/\s*```$/i, '');

    // Тепер можна парсити
    const questions = JSON.parse(text);
    return questions;

    } catch (error) {
    console.error('Error calling Gemini API:', error.response?.data || error.message);
    throw new Error('Помилка при виклику Gemini API.');
  }
};

module.exports = { callGeminiAPI };
