# Quiz Party Hub - Backend

This is the backend server for the Quiz Party Hub project.

## Features

- User authentication via Firebase (Google Sign-In)
- AI quiz question generation using Gemini API
- User score tracking
- Leaderboard displaying top players
- Profile customization (nickname and avatar)

## Technologies Used

- Node.js
- Express.js
- Firebase Admin SDK
- Google Gemini API
- Firestore database

## Installation

1. Clone the repository:
