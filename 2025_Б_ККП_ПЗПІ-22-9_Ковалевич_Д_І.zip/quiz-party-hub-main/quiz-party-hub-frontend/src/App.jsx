import { useState } from "react";
import "./App.css";
import "tailwindcss";
import lillogo from "./assets/LittleMain_Logo.svg";
import logo from "./assets/Main_Logo.svg";
import img1 from "./assets/img1_music.svg";
import img2 from "./assets/img2_gamepad.svg";
import img3 from "./assets/img3_film.svg";
import img4 from "./assets/img4_sticker.svg";
import img5 from "./assets/img5_cup.svg";
import dots from "./assets/decor_points.svg";
import { FaInstagram, FaDiscord, FaTelegram, FaEnvelope } from "react-icons/fa";
import { FaXTwitter } from "react-icons/fa6";

// Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.10.0/firebase-app.js";
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
} from "https://www.gstatic.com/firebasejs/10.10.0/firebase-auth.js";

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

async function signInAndGetToken() {
  const provider = new GoogleAuthProvider();
  try {
    const result = await signInWithPopup(auth, provider);
    const token = await result.user.getIdToken();
    console.log("Ваш Firebase ID Token:", token);
    document.getElementById("token").textContent = token;
  } catch (error) {
    console.error(error);
    alert("Помилка авторизації. Дивись консоль.");
  }
}

window.signInAndGetToken = signInAndGetToken;

const reviews = Array(2).fill({ avatar: "", text: "" }); // Placeholder, під'єднати до бекенду

function App() {
  return (
    <>
      {/* --------------------------------= HEADER =------------------------------------ */}
      <div className="w-full flex flex-row justify-between p-3 items-center">
        <div>
          <img src={lillogo} alt="Логотип" className="w-10 h-auto" />
        </div>
        <div>
          <ul className="flex flex-row space-x-6">
            <li>
              <a href="#">link</a>
            </li>
            <li>
              <a href="#">link</a>
            </li>
            <li>
              <a href="#">link</a>
            </li>
            <li>
              <a href="#">link</a>
            </li>
            <li>
              <a href="#">link</a>
            </li>
          </ul>
        </div>

        <div className="flex flex-row space-x-6">
          <button
            class="w-20 h-10 text-white bg-sky-500 hover:bg-sky-700 rounded-2xl"
            onclick={signInAndGetToken}
          >
            Login
          </button>
        </div>
      </div>

      {/* ----------------------------------BLOCK------------------------------------ */}
      <div
        className="w-full flex flex-col justify-center items-center p-10"
        style={{ backgroundColor: "rgba(255, 226, 81, 1)" }}
      >
        <div>
          <img src={logo} alt="Великий Логотип" className="w-60 h-auto" />
        </div>

        <div className="text-5xl font-bold text-center py-10">
          Спробуй себе у <br />
          Quiz Party Hub!
        </div>

        <button class="w-40 h-10 text-white bg-sky-500 hover:bg-sky-700 rounded-2xl">
          Розпочати
        </button>
      </div>

      {/* ----------------------------------BLOCK------------------------------------ */}
      <div
        className="w-full flex flex-col pb-10"
        style={{ backgroundColor: "rgba(247, 237, 217, 1)" }}
      >
        {/* 1st block */}
        <div className="flex flex-col items-center w-full">
          <div className="pt-5 text-2xl">Обери свою тему для гри</div>
          <div className="flex flex-row justify-center items-center space-x-10 py-10">
            <div className="flex flex-col items-center">
              <div
                className="block w-30 h-30 bg-slate-200 rounded-full flex items-center justify-center"
                style={{ backgroundColor: "rgba(86, 184, 97, 1)" }}
              >
                <img src={img1} alt="img1" className="w-20 h-auto" />
              </div>
              <div>Музика</div>
            </div>
            <div className="flex flex-col items-center">
              <div
                className="block w-30 h-30 bg-slate-200 rounded-full flex items-center justify-center"
                style={{ backgroundColor: "rgba(0, 149, 213, 1)" }}
              >
                <img src={img2} alt="img2" className="w-20 h-auto" />
              </div>
              <div>Ігри</div>
            </div>
            <div className="flex flex-col items-center">
              <div
                className="block w-30 h-30 bg-slate-200 rounded-full flex items-center justify-center"
                style={{ backgroundColor: "rgba(248, 48, 69, 1)" }}
              >
                <img src={img3} alt="img3" className="w-20 h-auto" />
              </div>
              <div>Фільми</div>
            </div>
            <div className="flex flex-col items-center">
              <div
                className="block w-30 h-30 bg-slate-200 rounded-full flex items-center justify-center"
                style={{ backgroundColor: "rgba(163, 188, 192, 1)" }}
              >
                <img src={img4} alt="img4" className="w-25 h-auto" />
              </div>
              <div>Меми</div>
            </div>
          </div>
        </div>

        {/* 2nd block */}
        <div className="flex flex-row justify-around pr-60 pl-60">
          <div className="flex flex-col items-center">
            <div className="py-5">Про гру</div>
            <div className="block w-70 min-h-90 bg-white rounded-2xl p-3">
              1
            </div>
          </div>
          <div className="flex flex-col items-center">
            <div className="py-5">Особливості</div>
            <div className="block w-70 min-h-90 bg-white rounded-2xl p-3">
              2
            </div>
          </div>
          <div className="flex flex-col items-center">
            <div className="py-5">Як грати</div>
            <div className="block w-70 min-h-90 bg-white rounded-2xl p-3">
              3
            </div>
          </div>
        </div>

        {/* 3rd block */}
        <div className="flex items-center justify-between w-full max-w-4xl mx-auto pt-20">
          {/* Блок 1 */}
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 bg-orange-400 rounded-full"></div>
            <div className="mt-2 font-semibold">Розпочни</div>
          </div>

          {/* Лінія */}
          <div className="flex-1 border-t-6 border-dashed border-gray-700 mx-2 "></div>

          {/* Блок 2 */}
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 bg-red-400 rounded-full"></div>
            <div className="mt-2 font-semibold">Клич друзів</div>
          </div>

          {/* Лінія */}
          <div className="flex-1 border-t-6 border-dashed border-gray-700 mx-2"></div>

          {/* Блок 3 */}
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 bg-green-400 rounded-full"></div>
            <div className="mt-2 font-semibold">Обирай тему</div>
          </div>

          {/* Лінія */}
          <div className="flex-1 border-t-6 border-dashed border-gray-700 mx-2"></div>

          {/* Блок 4 */}
          <div className="flex flex-col items-center">
            <div className="w-6 h-6 bg-blue-400 rounded-full"></div>
            <div className="mt-2 font-semibold">Грай</div>
          </div>
        </div>
      </div>

      {/* ----------------------------------BLOCK------------------------------------ */}
      <div className="w-full flex flex-col items-center py-6 bg-white rounded-lg shadow">
        {/* Заголовок з кубком */}
        <div className="flex items-center space-x-4 mb-4">
          <div className="w-16 h-16 bg-blue-400 p-3 rounded-full flex items-center justify-center">
            <img src={img5} alt="Кубок" className="w-10 h-auto" />
          </div>
          <div className="text-2xl font-semibold">Таблиця лідерів</div>
        </div>

        {/* Підзаголовок */}
        <div className="text-gray-600 mb-4">
          Відповідай правильно, щоб піднятись в топі!
        </div>

        {/* Таблиця */}
        <div className="w-full max-w-xl">
          <table className="w-full table-auto border-separate border-spacing-y-2">
            <thead>
              <tr className="bg-gray-200 text-left">
                <th className="px-4 py-2 rounded-l-md">Місце</th>
                <th className="px-4 py-2">Нікнейм</th>
                <th className="px-4 py-2 rounded-r-md">Очки</th>
              </tr>
            </thead>
            <tbody>
              {Array.from({ length: 10 }).map((_, idx) => (
                <tr key={idx} className="bg-white shadow rounded">
                  <td className="px-4 py-2">1</td>
                  <td className="px-4 py-2">---------</td>
                  <td className="px-4 py-2">---------</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* ----------------------------------BLOCK------------------------------------ */}
      <div className="bg-[#F7EDD9] py-8 flex flex-col items-center rounded-xl">
        <h2 className="text-xl font-semibold mb-6">Відгуки гравців</h2>

        {/* Слайдер з відгуками */}
        <div className="flex items-center space-x-4 mb-8">
          <button className="text-2xl text-gray-400">{"‹"}</button>

          <div className="flex space-x-4">
            {reviews.map((review, i) => (
              <div
                key={i}
                className="bg-white w-60 h-60 rounded-xl shadow p-2 flex flex-col items-center"
              >
                <div className="w-8 h-8 bg-gray-300 rounded-full mb-2" />
                <div className="text-sm text-center text-gray-600 mt-2">
                  ---------
                </div>
              </div>
            ))}
          </div>

          <button className="text-2xl text-gray-400">{"›"}</button>
        </div>

        {/* Соцмережі */}
        <div className="text-lg font-semibold mb-4">
          Поділись своїми враженнями
        </div>
        <div className="flex space-x-4">
          <a
            href="https://twitter.com"
            target="_blank"
            rel="noreferrer"
            className="bg-violet-400 p-2 rounded-xl"
          >
            <FaXTwitter className="text-black text-xl" />
          </a>
          <a
            href="https://instagram.com"
            target="_blank"
            rel="noreferrer"
            className="bg-rose-400 p-2 rounded-xl"
          >
            <FaInstagram className="text-black text-xl" />
          </a>
          <a
            href="https://discord.com"
            target="_blank"
            rel="noreferrer"
            className="bg-green-400 p-2 rounded-xl"
          >
            <FaDiscord className="text-black text-xl" />
          </a>
          <a
            href="https://t.me"
            target="_blank"
            rel="noreferrer"
            className="bg-orange-400 p-2 rounded-xl"
          >
            <FaTelegram className="text-black text-xl" />
          </a>
          <a
            href="mailto:example@email.com"
            className="bg-sky-400 p-2 rounded-xl"
          >
            <FaEnvelope className="text-black text-xl" />
          </a>
        </div>
      </div>

      {/* --------------------------------= FOOTER =------------------------------------ */}

      <div className="w-full h-20 flex flex-row justify-between">123</div>
    </>
  );
}

export default App;
